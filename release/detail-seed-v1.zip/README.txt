Xingmu TV detail seed v1
source: bfzy1 (macapi1 MacCMS)
generated_at: 2026-10-22T05:52:28+08:00
count: 500
usage: read detail_seed.json, index entries by vodId; serve entries[*].detailJson as the detail payload.
